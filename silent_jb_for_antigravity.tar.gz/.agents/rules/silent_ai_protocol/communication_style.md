---
trigger: always_on
description: "Стиль общения с пользователем"
---
